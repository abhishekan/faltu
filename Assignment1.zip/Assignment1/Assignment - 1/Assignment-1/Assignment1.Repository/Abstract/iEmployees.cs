﻿using Assignment1.Repository.EntityDataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1.Repository.Abstract
{
    interface iEmployees
    {
        void i_AddEmployee(EMPLOYEE employee);
        IEnumerable<EMPLOYEE> i_displayEmployee();
        EMPLOYEE i_findEmployeeById(int id);
        void i_updateEmployeeById(EMPLOYEE employee);
        void i_RemoveEmployeeById(int id);
        IEnumerable<EMPLOYEE> i_searchEmployeeByTitle(string name);
    }
}
