﻿using Assignment1.Repository.EntityDataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1.Repository.Abstract
{
    interface iCompanies
    {
        int i_AddCompany(COMPANy company);
        IEnumerable<COMPANy> i_displayCompany();
        COMPANy i_findCompanyById(int id);
        void i_updateCompanyById(COMPANy company);
        void i_RemoveCompanyById(int id);
        IEnumerable<COMPANy> i_searchCompanyByTitle(string name);

    }
}
