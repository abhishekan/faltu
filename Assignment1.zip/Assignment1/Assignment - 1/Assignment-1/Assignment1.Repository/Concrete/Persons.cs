﻿using Assignment1.Repository.Abstract;
using Assignment1.Repository.EntityDataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1.Repository.Concrete
{
    public class Persons : iPersons
    {
        Assignment1Entities context = new Assignment1Entities();

        //Method for ADDING a Person.
        public int i_AddPerson(PERSON person)
        {
            context.PERSONS.Add(person);
            context.SaveChanges();
            int id = person.PersonId;
            return id;

        }


        //Method for DISPLAYING ALL the Person.
        public IEnumerable<PERSON> i_displayPerson()
        {
            return context.PERSONS.ToList();
        }


        //Method for DISPLAYING the Person by id.
        public PERSON i_findPersonById(int id)
        {
            return context.PERSONS.Find(id);
        }


        //Method for UPDATING the Person by id.
        public void i_updatePersonById(PERSON OldPersonDetails)
        {
            PERSON NewPersonDetails = i_findPersonById(OldPersonDetails.PersonId);

            NewPersonDetails.PersonId = OldPersonDetails.PersonId;
            NewPersonDetails.FirstName = OldPersonDetails.FirstName;
            NewPersonDetails.LastName = OldPersonDetails.LastName;

            context.SaveChanges();
        }


        //Method for DELETING the Person by id.
        public void i_RemovePersonById(int id)
        {
            PERSON person = context.PERSONS.Find(id);
            context.PERSONS.Remove(person);
            context.SaveChanges();
        }


        //Method for SEARCHING the Person by Name.
        public IEnumerable<PERSON> i_searchPersonByTitle(string name)
        {
            IEnumerable<PERSON> search = context.PERSONS.Where(p => p.FirstName.Contains(name));
            return search;
        }
    }
}
