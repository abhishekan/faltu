﻿using Assignment1.Repository.Abstract;
using Assignment1.Repository.EntityDataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1.Repository.Concrete
{
    public class Companies : iCompanies
    {
        Assignment1Entities context = new Assignment1Entities();

        //Method for ADDING a Company.
        public int i_AddCompany(COMPANy company)
        {
            context.COMPANIES.Add(company);
            context.SaveChanges();
            int id = company.CompanyId;

            return id;
        }


        //Method for DISPLAYING ALL the Companies.
        public IEnumerable<COMPANy> i_displayCompany()
        {
            return context.COMPANIES.ToList();
        }


        //Method for DISPLAYING the Companies by id.
        public COMPANy i_findCompanyById(int id)
        {
            return context.COMPANIES.Find(id);
        }


        //Method for UPDATING the Company by id.
        public void i_updateCompanyById(COMPANy OldCompanyDetails)
        {
            COMPANy NewCompanyDetails = i_findCompanyById(OldCompanyDetails.CompanyId);

            NewCompanyDetails.CompanyId = OldCompanyDetails.CompanyId;
            NewCompanyDetails.Name = OldCompanyDetails.Name;
            NewCompanyDetails.Address = OldCompanyDetails.Address;

            context.SaveChanges();
        }


        //Method for DELETING the Company by id.
        public void i_RemoveCompanyById(int id)
        {
            COMPANy company = context.COMPANIES.Find(id);
            context.COMPANIES.Remove(company);
            context.SaveChanges();
        }


        //Method for SEARCHING the Company by Name.
        public IEnumerable<COMPANy> i_searchCompanyByTitle(string name)
        {
            IEnumerable<COMPANy> search = context.COMPANIES.Where(p => p.Name.Contains(name)).ToList();
            return search;
        }

    }
}
