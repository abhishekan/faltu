﻿using Assignment1.Repository.Concrete;
using Assignment1.Repository.EntityDataModel;
using Assignmnet1.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Assignmnet1.Controllers
{
    public class PersonsController : Controller
    {
        //Creating the instance of Person Repository, to call the methods of repository.
        Persons repo = new Persons();


        //Method for DISPLAYING ALL the Person.
        [HttpGet]
        public ActionResult GetAllPerson()
        {
            IEnumerable<PERSON> personList = repo.i_displayPerson();
            List<Employee> List = new List<Employee>();

            foreach (var i in personList)
            {
                Employee personViewModel = new Employee();

                personViewModel.PersonId = i.PersonId;
                personViewModel.FirstName = i.FirstName;
                personViewModel.LastName = i.LastName;
                personViewModel.Address_Street = i.Address_Street;
                personViewModel.Address_City = i.Address_City;
                personViewModel.Address_Zip = i.Address_Zip;
                personViewModel.Address_State = i.Address_State;
                personViewModel.Address_Country = i.Address_Country;
                personViewModel.EmailAddress = i.EmailAddress;
                personViewModel.CellPhone = i.CellPhone;

                List.Add(personViewModel);

            }
            return View(List);
        }

        //Method for DISPLAYING the Person by id.
        [HttpGet]
        public ActionResult GetPersonById(int id)
        {
            PERSON person = repo.i_findPersonById(id);

            Employee personViewModel = new Employee();

            personViewModel.PersonId = person.PersonId;
            personViewModel.FirstName = person.FirstName;
            personViewModel.LastName = person.LastName;
            personViewModel.Address_Street = person.Address_Street;
            personViewModel.Address_City = person.Address_City;
            personViewModel.Address_Zip = person.Address_Zip;
            personViewModel.Address_State = person.Address_State;
            personViewModel.Address_Country = person.Address_Country;
            personViewModel.EmailAddress = person.EmailAddress;
            personViewModel.CellPhone = person.CellPhone;

            return View(personViewModel);
        }


        ////Method for ADDING a Person.
        //[HttpGet]
        //public ViewResult AddCompany()
        //{
        //    return View();
        //}

        //[HttpPost]
        //public ActionResult AddCompany(Employee companyViewModel)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        COMPANy company = new COMPANy();

        //        company.CompanyId = companyViewModel.CompanyId;
        //        company.Name = companyViewModel.Name;
        //        company.Address = companyViewModel.Address;

        //        repo.i_AddCompany(company);

        //        return RedirectToAction("GetAllCompanies");
        //    }
        //    return View();
        //}


        ////Method for UPDATING the Person by id.
        //[HttpGet]
        //public ActionResult UpdateCompany(int id)
        //{
        //    COMPANy company = repo.i_findCompanyById(id);

        //    Employee companyViewModel = new Employee();

        //    companyViewModel.CompanyId = company.CompanyId;
        //    companyViewModel.Name = company.Name;
        //    companyViewModel.Address = company.Address;

        //    return View(companyViewModel);
        //}

        //[HttpPost]
        //public ActionResult UpdateCompany(Employee companyViewModel)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        COMPANy company = new COMPANy();

        //        company.CompanyId = companyViewModel.CompanyId;
        //        company.Name = companyViewModel.Name;
        //        company.Address = companyViewModel.Address;

        //        repo.i_updateCompanyById(company);

        //        return RedirectToAction("GetAllCompanies");
        //    }
        //    return View();
        //}


        ////Method for DELETING the Person by id.
        //[HttpGet]
        //public ActionResult DeleteCompany(int id)
        //{
        //    COMPANy company = repo.i_findCompanyById(id);

        //    Employee companyViewModel = new Employee();

        //    companyViewModel.CompanyId = company.CompanyId;
        //    companyViewModel.Name = company.Name;
        //    companyViewModel.Address = company.Address;

        //    return View(companyViewModel);
        //}

        //[ActionName("DeleteCompany")]
        //[HttpPost]
        //public ActionResult FinalDelete(int id)
        //{
        //    repo.i_RemoveCompanyById(id);
        //    return RedirectToAction("GetAllCompanies");
        //}


        ////Method for SEARCHING the Person by Name.
        //[HttpGet]
        //public ActionResult SearchCompany(string name)
        //{
        //    if (name.Length != 0)
        //    {
        //        IEnumerable<COMPANy> companyList = null;
        //        companyList = repo.i_searchCompanyByTitle(name);

        //        List<Employee> List = new List<Employee>();

        //        foreach (var i in companyList)
        //        {
        //            Employee companyViewModel = new Employee();

        //            companyViewModel.CompanyId = i.CompanyId;
        //            companyViewModel.Name = i.Name;
        //            companyViewModel.Address = i.Address;

        //            List.Add(companyViewModel);
        //        }
        //        return View(List);
        //    }
        //    else
        //    {
        //        return View();
        //    }
        //}

    }
}
