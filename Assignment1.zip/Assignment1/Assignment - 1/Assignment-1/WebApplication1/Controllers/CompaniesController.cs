﻿
using Assignment1.Repository.Concrete;
using Assignment1.Repository.EntityDataModel;
using Assignmnet1.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Assignmnet1.Controllers
{
    public class CompaniesController : Controller
    {
        //Creating the instance of Company Repository, to call the methods of repository.
        Companies repo = new Companies();


        //Method for DISPLAYING ALL the Companies.
        [HttpGet]
        public ActionResult GetAllCompanies()
        {
            IEnumerable<COMPANy> companyList = repo.i_displayCompany();
            List<Employee> List = new List<Employee>();

            foreach (var i in companyList)
            {
                Employee companyViewModel = new Employee();

                companyViewModel.CompanyId = i.CompanyId;
                companyViewModel.Name = i.Name;
                companyViewModel.Address = i.Address;

                List.Add(companyViewModel);

            }
            return View(List);
        }

        //Method for DISPLAYING the Company by id.
        [HttpGet]
        public ActionResult GetCompanyById(int id)
        {
            COMPANy company = repo.i_findCompanyById(id);

            Employee companyViewModel = new Employee();

            companyViewModel.CompanyId = company.CompanyId;
            companyViewModel.Name = company.Name;
            companyViewModel.Address = company.Address;

            return View(companyViewModel);
        }


        //Method for ADDING a Company.
        [HttpGet]
        public ViewResult AddCompany()
        {
            return View();
        }

        [HttpPost]
        public ActionResult AddCompany(Employee companyViewModel)
        {
            if (ModelState.IsValid)
            {
                COMPANy company = new COMPANy();

                company.CompanyId = companyViewModel.CompanyId;
                company.Name = companyViewModel.Name;
                company.Address = companyViewModel.Address;

                repo.i_AddCompany(company);

                return RedirectToAction("GetAllCompanies");
            }
            return View();
        }


        //Method for UPDATING the Company by id.
        [HttpGet]
        public ActionResult UpdateCompany(int id)
        {
            COMPANy company = repo.i_findCompanyById(id);

            Employee companyViewModel = new Employee();

            companyViewModel.CompanyId = company.CompanyId;
            companyViewModel.Name = company.Name;
            companyViewModel.Address = company.Address;

            return View(companyViewModel);
        }

        [HttpPost]
        public ActionResult UpdateCompany(Employee companyViewModel)
        {
            if (ModelState.IsValid)
            {
                COMPANy company = new COMPANy();

                company.CompanyId = companyViewModel.CompanyId;
                company.Name = companyViewModel.Name;
                company.Address = companyViewModel.Address;

                repo.i_updateCompanyById(company);

                return RedirectToAction("GetAllCompanies");
            }
            return View();
        }


        //Method for DELETING the Company by id.
        [HttpGet]
        public ActionResult DeleteCompany(int id)
        {
            COMPANy company = repo.i_findCompanyById(id);

            Employee companyViewModel = new Employee();

            companyViewModel.CompanyId = company.CompanyId;
            companyViewModel.Name = company.Name;
            companyViewModel.Address = company.Address;

            return View(companyViewModel);
        }

        [ActionName("DeleteCompany")]
        [HttpPost]
        public ActionResult FinalDelete(int id)
        {
            repo.i_RemoveCompanyById(id);
            return RedirectToAction("GetAllCompanies");
        }


        //Method for SEARCHING the Companies by Name.
        [HttpGet]
        public ActionResult SearchCompany(string name)
        {
            if (name.Length != 0)
            {
                IEnumerable<COMPANy> companyList = null;
                companyList = repo.i_searchCompanyByTitle(name);

                List<Employee> List = new List<Employee>();

                foreach (var i in companyList)
                {
                    Employee companyViewModel = new Employee();

                    companyViewModel.CompanyId = i.CompanyId;
                    companyViewModel.Name = i.Name;
                    companyViewModel.Address = i.Address;

                    List.Add(companyViewModel);
                }
                return View(List);
            }
            else
            {
                return View();
            }
        }

    }
}
