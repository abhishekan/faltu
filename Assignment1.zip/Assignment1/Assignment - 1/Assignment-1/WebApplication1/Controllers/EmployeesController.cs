﻿using Assignment1.Repository.Concrete;
using Assignment1.Repository.EntityDataModel;
using Assignmnet1.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Assignmnet1.Controllers
{
    public class EmployeesController : Controller
    {
        //Creating the instance of Repository, to call the methods of repository.
        Employees employeeRepo = new Employees();
        Persons personRepo = new Persons();
        Companies companyRepo = new Companies();


        //Method for DISPLAYING ALL the Employees.
        [HttpGet]
        public ActionResult GetAllEmployees()
        {
            IEnumerable<EMPLOYEE> companyList = employeeRepo.i_displayEmployee();
            List<Employee> List = new List<Employee>();

            foreach (var i in companyList)
            {
                Employee companyViewModel = new Employee();

                companyViewModel.Id = i.Id;
                companyViewModel.Title = i.Title;
                companyViewModel.CompanyId = i.CompanyId;
                companyViewModel.PersonId = i.PersonId;
                companyViewModel.Active = i.Active;
                companyViewModel.JoiningDate = i.JoiningDate;
                companyViewModel.TerminationDate = i.TerminationDate;
                companyViewModel.CompanyEmailAddress = i.CompanyEmailAddress;

                List.Add(companyViewModel);

            }
            return View(List);
        }


        //Method for DISPLAYING the Employee by id.
        [HttpGet]
        public ActionResult GetEmployeeById(int id)
        {
            EMPLOYEE employee = employeeRepo.i_findEmployeeById(id);

            Employee employeeViewModel = new Employee();

            employeeViewModel.Id = employee.Id;
            employeeViewModel.Title = employee.Title;
            employeeViewModel.CompanyId = employee.CompanyId;
            employeeViewModel.PersonId = employee.PersonId;
            employeeViewModel.Active = employee.Active;
            employeeViewModel.JoiningDate = employee.JoiningDate;
            employeeViewModel.TerminationDate = employee.TerminationDate;
            employeeViewModel.CompanyEmailAddress = employee.CompanyEmailAddress;

            return View(employeeViewModel);
        }


        //Method for ADDING a Employee.
        [HttpGet]
        public ViewResult AddEmployee()
        {
            IEnumerable<COMPANy> companyList = companyRepo.i_displayCompany();
            Employee viewModel = new Employee();
            viewModel.CompanyList = new List<SelectListItem>();

            foreach (var item in companyList)
            {
                SelectListItem companyName = new SelectListItem();
                companyName.Value = item.Name;
                companyName.Text = item.Name;

                viewModel.CompanyList.Add(companyName);
            }
            SelectListItem Other = new SelectListItem() { Text="Other",Value="Other"};
            viewModel.CompanyList.Add(Other);
            return View(viewModel);
        }

        [HttpPost]
        public ActionResult AddEmployee(Employee employeeViewModel)
        {
            if (ModelState.IsValid)
            {
                EMPLOYEE employee = new EMPLOYEE();
                PERSON person = new PERSON();

                person.FirstName = employeeViewModel.FirstName;
                person.LastName = employeeViewModel.LastName;
                person.Address_Street = employeeViewModel.Address_Street;
                person.Address_City = employeeViewModel.Address_City;
                person.Address_Zip = employeeViewModel.Address_Zip;
                person.Address_State = employeeViewModel.Address_State;
                person.Address_Country = employeeViewModel.Address_Country;
                person.EmailAddress = employeeViewModel.EmailAddress;
                person.CellPhone = employeeViewModel.CellPhone;

                int pid = personRepo.i_AddPerson(person);

                IEnumerable<COMPANy> name=companyRepo.i_searchCompanyByTitle(employeeViewModel.Name);
                if (name.Count()>0)
                {
                    foreach (var id in name)
                    {
                        employee.CompanyId = id.CompanyId;
                    }
                }
                else
                {
                    COMPANy company = new COMPANy();
                    company.Name = employeeViewModel.Name;
                    company.Address = employeeViewModel.Address;

                    int id = companyRepo.i_AddCompany(company);
                    employee.CompanyId = id;
                }

                employee.Title = employeeViewModel.Title;
                employee.PersonId = pid;
                employee.Active = employeeViewModel.Active;
                employee.JoiningDate = employeeViewModel.JoiningDate;
                employee.TerminationDate = employeeViewModel.TerminationDate;
                employee.CompanyEmailAddress = employeeViewModel.CompanyEmailAddress;

                employeeRepo.i_AddEmployee(employee);
                
                return RedirectToAction("GetAllEmployees");
            }
            return View();
        }


        //Method for UPDATING the Employee by id.
        [HttpGet]
        public ActionResult UpdateEmployee(int id)
        {
            EMPLOYEE employee = employeeRepo.i_findEmployeeById(id);

            Employee employeeViewModel = new Employee();

            employeeViewModel.Id = employee.Id;
            employeeViewModel.Title = employee.Title;
            employeeViewModel.JoiningDate = employee.JoiningDate;
            employeeViewModel.TerminationDate = employee.TerminationDate;
            employeeViewModel.CompanyEmailAddress = employee.CompanyEmailAddress;

            return View(employeeViewModel);
        }

        [HttpPost]
        public ActionResult UpdateEmployee(Employee employeeViewModel)
        {
            if (ModelState.IsValid)
            {
                EMPLOYEE employee = new EMPLOYEE();

                employee.Id = employeeViewModel.Id;
                employee.Title = employeeViewModel.Title;
                employee.JoiningDate = employeeViewModel.JoiningDate;
                employee.TerminationDate = employeeViewModel.TerminationDate;
                employee.CompanyEmailAddress = employeeViewModel.CompanyEmailAddress;

                employeeRepo.i_updateEmployeeById(employee);

                return RedirectToAction("GetAllEmployees");
            }
            return View();
        }


        //Method for DELETING the Employee by id.
        [HttpGet]
        public ActionResult DeleteEmployee(int id)
        {
            EMPLOYEE employee = employeeRepo.i_findEmployeeById(id);

            Employee employeeViewModel = new Employee();

            employeeViewModel.Id = employee.Id;
            employeeViewModel.Title = employee.Title;
            employeeViewModel.CompanyId = employee.CompanyId;
            employeeViewModel.PersonId = employee.PersonId;
            employeeViewModel.Active = employee.Active;
            employeeViewModel.JoiningDate = employee.JoiningDate;
            employeeViewModel.TerminationDate = employee.TerminationDate;
            employeeViewModel.CompanyEmailAddress = employee.CompanyEmailAddress;

            return View(employeeViewModel);
        }

        [ActionName("DeleteEmployee")]
        [HttpPost]
        public ActionResult FinalDelete(int id)
        {
            employeeRepo.i_RemoveEmployeeById(id);
            return RedirectToAction("GetAllEmployees");
        }


        //Method for SEARCHING the Employee by Title.
        [HttpGet]
        public ActionResult SearchEmployee(string name)
        {
            if (name.Length != 0)
            {
                IEnumerable<EMPLOYEE> employeeList = null;
                employeeList = employeeRepo.i_searchEmployeeByTitle(name);

                List<Employee> List = new List<Employee>();

                foreach (var item in employeeList)
                {
                    Employee employeeViewModel = new Employee();

                    employeeViewModel.Id = item.Id;
                    employeeViewModel.Title = item.Title;
                    employeeViewModel.CompanyId = item.CompanyId;
                    employeeViewModel.PersonId = item.PersonId;
                    employeeViewModel.Active = item.Active;
                    employeeViewModel.JoiningDate = item.JoiningDate;
                    employeeViewModel.TerminationDate = item.TerminationDate;
                    employeeViewModel.CompanyEmailAddress = item.CompanyEmailAddress;

                    List.Add(employeeViewModel);
                }
                return View(List);
            }
            else
            {
                return View();
            }
        }
    }
}
