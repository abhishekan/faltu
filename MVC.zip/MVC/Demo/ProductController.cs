﻿using MvcDemoApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MvcDemoApp.Controllers
{
    public class ProductController : Controller
    {
        public ViewResult SayHello(string name)
        {
            //return "Hello " + name;
            ViewBag.Username = name;
            return View();
        }

        public ViewResult GetProducts()
        {
            var productModel = new Product()
            {
                ProductId = 1,
                Name = "Cricket Kit",
                Price = 5000,
                Quantity = 50
            };

            return View(productModel);
        }
    }
}