﻿
-- Assignment - 4 :

-- Stored Procedures: 

-- 4. Write the following stored procedure using SQL Server in BookStoreDB database to support following operations:


-- a. Get All the books written by specific author
 CREATE PROCEDURE GetBook @AuthorId int
 AS
 BEGIN
		SELECT * FROM BOOK WHERE BookId IN (SELECT Bid FROM BOOK_AUTHOR WHERE Aid = @AuthorId) 		
 END

EXECUTE GetBook 1




-- b. Get all the books written by specific author and published by specific publisher belonging to “Technical” book Category
 CREATE PROCEDURE GetAllBook @AuthorId int, @PublisherName char(50), @CategoryName char(50)
 AS
 BEGIN
		SELECT * FROM BOOK WHERE bookid 
		IN (SELECT BookId FROM BOOK_AUTHOR WHERE Aid = @AuthorId) 
		AND B_Pid = (SELECT PublisherId FROM PUBLISHER WHERE PublisherName = @PublisherName)
		AND B_Cid = (SELECT categoryid FROM category WHERE Categoryname = @CategoryName)		
 END

 EXECUTE GetAllBook 1, TechMax, Technical

 

 
 -- c. Get total books published by each publisher.
 CREATE PROCEDURE GetTotalBooks
 AS
 BEGIN
		SELECT B_Pid, COUNT(BookId) FROM BOOK WHERE B_Pid IN (SELECT DISTINCT(B_Pid) FROM BOOK) GROUP BY B_Pid 		
 END

EXECUTE GetTotalBooks




-- d. Insert a particular book
 CREATE PROCEDURE InsertBook @AuthorId int, @Title char(50), @Description char(50), @Price bigint, @ISBN bigint, @PublicationDate date, @Image char(50), @B_Cid int, @B_Pid int								
 AS
 DECLARE @Bid int
 BEGIN
		
		INSERT INTO BOOK(Title, Description, Price, ISBN, PublicationDate, Image, B_Cid, B_Pid) VALUES(@Title, @Description, @Price, @ISBN, @PublicationDate, @Image, @B_Cid, @B_Pid)
		SELECT @Bid=BookId From BOOK WHERE Title=@Title 
		INSERT INTO BOOK_AUTHOR (Bid,Aid) VALUES(@Bid,@AuthorId)
 END

 EXECUTE InsertBook 2, 'PHP', 'PHP_Description', 150, 111, '11-11-2011', 'C:\Users\omkarpa\Pictures\PHP.jpeg', 1, 2



 
-- e. Update a particular book by id
 CREATE PROCEDURE UpdateBook @BookId int, @Price bigint
 AS 
 BEGIN
		
		UPDATE BOOK SET Price = @Price WHERE BookId = @BookId
 END

 EXECUTE UpdateBook 2, 2000



 
-- f. Delete a particular book by id
 CREATE PROCEDURE DeleteBook @BookId int
 AS 
 BEGIN
		
		DELETE FROM BOOK WHERE BookId = @BookId
 END

 EXECUTE DeleteBook 2