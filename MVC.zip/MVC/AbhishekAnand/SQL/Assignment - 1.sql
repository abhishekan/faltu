
-- Assignment - 1 :

-- Create Database
CREATE DATABASE BookStoreDB
USE BookStoreDB


--Author Table
CREATE TABLE AUTHOR(
	AuthorId int IDENTITY(1,1) NOT NULL,
	AuthorName char(50), 
	DateOfBirth date,
	State char(50),
	City char(50),
	Phone bigint 
)
ALTER TABLE AUTHOR ADD CONSTRAINT pk_authorId PRIMARY KEY (AuthorId)
SELECT * FROM AUTHOR



--Publisher Table
CREATE TABLE PUBLISHER(
	PublisherId int IDENTITY(1,1) NOT NULL,
	PublisherName char(50),
	DateOfBirth date,
	State char(50),
	City char(50),
	Phone bigint 
)	
ALTER TABLE PUBLISHER ADD CONSTRAINT pk_publisherId PRIMARY KEY (PublisherId)
SELECT * FROM PUBLISHER 



--Category Table
CREATE TABLE CATEGORY(
	CategoryId int IDENTITY(1,1) NOT NULL,
	Categoryname char(50),
	Description char(50)
)
ALTER TABLE CATEGORY ADD CONSTRAINT pk_categoryId PRIMARY KEY (CategoryId)
SELECT * FROM CATEGORY



--Book Table
CREATE TABLE BOOK(
	BookId int IDENTITY(1,1) NOT NULL,
	Title char(50),
	Description char(50),
	Price bigint,
	ISBN bigint,
	PublicationDate date,
	Image char(100)

)
ALTER TABLE BOOK ADD CONSTRAINT pk_bookId PRIMARY KEY (BookId)
SELECT * FROM BOOK



--Order Table
CREATE TABLE [ORDER](
	OrderId int IDENTITY(1,1) NOT NULL,
	Date date,
	Quantity int,
	UnitPrice bigint,
	ShipingAddress char(50) 
)
ALTER TABLE [ORDER] ADD CONSTRAINT pk_orderId PRIMARY KEY (OrderId)
SELECT * FROM [ORDER]