﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BookStoreApp.Core;

namespace BookStoreApp.Repository
{
    public interface iBookRepository
    {
        void i_AddBook(Book book);
        IEnumerable<Book> i_displayBook();
        Book i_findBookById(int id);
        void i_updateBookById(Book book);
        int i_RemoveById(int id);
        Book i_All_BooksBy_Specific_Author(Book book);
        Book i_All_booksBy_specificAuthor_and_Publisher_BelongsTo_TechnicalCategory(Book book);
        Book i_Get_Books_by_eachPublisher();
    }
}
