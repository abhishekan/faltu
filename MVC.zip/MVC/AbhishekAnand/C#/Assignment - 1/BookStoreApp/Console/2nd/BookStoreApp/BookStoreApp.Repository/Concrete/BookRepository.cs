﻿
//BookStoreApp.Repository

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BookStoreApp.Core;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace BookStoreApp.Repository
{
	//BookRepository Class
    public class BookRepository : ApplicationException, iBookRepository
    {

           private static string conStr = ConfigurationManager.ConnectionStrings["con1"].ConnectionString;
           private static SqlConnection con;

           public static bool GetConnection()
            {
                try
                {
                    con = new SqlConnection(conStr);
                    con.Open();
                    Console.WriteLine("\nConnected successfully");
                    return true;
                }
                catch (SqlException ex)
                {
                    Console.WriteLine(ex.Message);
                }
                return false;
            }


            public static bool CloseConnection()
            {
                try
                {
                    if(con.State == System.Data.ConnectionState.Open)
                    {
                        con.Close();
                        Console.WriteLine("\nConnection closed successfully");
                    }
                    return true;
                }
                catch (SqlException ex)
                {
                    Console.WriteLine(ex.Message);
                }
            
             return false;
            }


        //List
        List<Book> bookList = new List<Book>();
        
		//Method for ADDING a Book.
        public void i_AddBook(Book book)
        {
            GetConnection();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            cmd.CommandText = "sp_InsertBook";
            cmd.Parameters.Add(new SqlParameter("@Title", SqlDbType.Char, 50, "Title")).Value = book.Title;
            cmd.Parameters.Add(new SqlParameter("@Description", SqlDbType.Char, 50, "Description")).Value = book.Description;
            cmd.Parameters.Add(new SqlParameter("@Price", SqlDbType.BigInt, 0, "Price")).Value = book.Price;
            cmd.Parameters.Add(new SqlParameter("@ISBN", SqlDbType.BigInt, 0, "ISBN")).Value = book.ISBN;
            cmd.Parameters.Add(new SqlParameter("@PublicationDate", SqlDbType.Date, 0, "PublicationDate")).Value = book.PublicationDate;
            cmd.Parameters.Add(new SqlParameter("@Image", SqlDbType.Char, 50, "Image")).Value = "C:\\Users\\abhishekan\\Pictures\\Angular_JS.jpeg";
            cmd.Parameters.Add(new SqlParameter("@B_Cid", SqlDbType.Int, 0, "B_Cid")).Value = book.CategoryId;
            cmd.Parameters.Add(new SqlParameter("@B_Pid", SqlDbType.Int, 0, "B_Pid")).Value = book.PublisherId;
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            cmd.ExecuteReader();
            System.Console.WriteLine("Inserting...\n");
            bookList.Add(book);
        }



		//Method for DISPLAYING ALL the Books
        public IEnumerable<Book> i_displayBook()
        {
            return bookList;
        }



		//Method for DISPLAYING the Books by id.
        public Book i_findBookById(int id)
        {
            Book b2 = bookList.Find(findBook => findBook.BookId == id);
            return b2;

        }



		//Method for UPDATING the book by id.
        public Book i_updateBookById(int id)
        {
            Book b2 = bookList.Find(findBook => findBook.BookId == id);
            return b2;         
        }



		//Method for DELETING the Book by id.
        public Book i_RemoveById(int id)
        {
             Book b2 = bookList.Find(findBook => findBook.BookId == id);
             bookList.Remove(b2);
             return b2;                         
        }
    }
}



