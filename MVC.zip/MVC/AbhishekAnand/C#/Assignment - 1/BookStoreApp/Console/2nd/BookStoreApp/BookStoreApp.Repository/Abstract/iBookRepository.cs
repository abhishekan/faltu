﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BookStoreApp.Core;

namespace BookStoreApp.Repository
{
    public interface iBookRepository
    {
        void i_AddBook(Book book);
        IEnumerable<Book> i_displayBook();
        Book i_findBookById(int id);
        Book i_updateBookById(int id);
        Book i_RemoveById(int id);
    }
}
