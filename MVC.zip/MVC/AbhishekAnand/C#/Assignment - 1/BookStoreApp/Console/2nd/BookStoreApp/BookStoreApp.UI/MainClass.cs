﻿
//BookStoreApp.UI
	
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace System.Environment { }
namespace BookStoreApp.UI
{
	//Main Class (UI)
    class MainClass
    {	
        static void Main(string[] args)
        {
            bookManager res = new bookManager();
            int option;
            do
            {
                Console.WriteLine("\n-------------------------------MAIN MENU------------------------------- ");
                Console.WriteLine(" 1) Adding new books\n 2) Displaying all books\n 3) Displaying a book by BookId\n 4) Updating a book by BookId\n 5) Deleting a book by BookId\n 6) Exit\n\n");
                Console.WriteLine("Enter Your Choice (any number from 1 to 6): ");

                if (!int.TryParse(Console.ReadLine(), out option))
                {
                    Console.WriteLine("Invalid Type. . .\n");
                }
                else
                {
                    switch (option)
                    {
                        case 1: res.AddBook();
                                break;


                        case 2: res.displayBook();
                                break;


                        case 3: res.findBookById();                               
                                break;


                        case 4: res.updateBookById();                               
                                break;


                        case 5: res.RemoveById();
                                break;


                        case 6: Console.WriteLine("Exit. . .");
                                Environment.Exit(0);
                                break;


                        default: Console.WriteLine("Invalid option. . . \n");
                                 break;
                    }
                }
            } while(true);
                              
        }
            
    }
}
    

