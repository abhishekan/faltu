﻿using BookStoreAppMVC.Models;
using System.Collections.Generic;
using System.Web.Mvc;

namespace BookStoreAppMVC.Controllers
{
    public class BookController : Controller
    {
        private static List<Book> db = new List<Book>()
        {
            new Book{BookId = 1, Title = "Dot.Net", Description = "ASP.Net MVC basics", Price = 500, ISBN = "SBIN3456", PublicationDate = "02/01/1999", CategoryId = 1, PublisherId = 1},
            new Book{BookId = 2, Title = "Java", Description = "Spring_Basics", Price = 1000, ISBN = "IVC7838", PublicationDate = "04/07/2000", CategoryId = 1, PublisherId = 2}
        };

        [HttpGet]
        public ActionResult GetBooks()
        {
            return View(db);          
        }

        [HttpGet]
        public ActionResult GetBookById(int? id)
        {
            Book bookModel = null;

            if (id != null)
            {
                bookModel = db.Find(p => p.BookId == id);
                return View(bookModel);
            }
            return HttpNotFound();
        }

        [HttpGet]
        public ViewResult AddBook()
        {
            return View();
        }

        [HttpPost]
        public ActionResult AddBook(Book book)
        {
            if (book != null)
            {
                int id = db.Count;
                book.BookId = id + 1;

                db.Add(book);
                return RedirectToAction("GetBooks");
            }

            return View();
        }

        [HttpGet]
        public ActionResult UpdateBook(int? id)
        {
            Book bookModel = null;

            if (id != null)
            {
                bookModel = db.Find(p => p.BookId == id);
                return View(bookModel);
            }

            return HttpNotFound();
        }

        //[ActionName("UpdateBook")]
        [HttpPost]
        public ActionResult UpdateBook(Book book)
        {
            if (book != null)
            {
                var existingBook = db.Find(p => p.BookId == book.BookId);

                if (existingBook != null)
                {
                    db.Remove(existingBook);
                    db.Add(book);
                    return RedirectToAction("GetBooks");
                }
            }
            return HttpNotFound();
        }

        [HttpGet]
        public ActionResult DeleteBook(int? id)
        {
            var bookModel = db.Find(p => p.BookId == id);

            if (bookModel != null)
            {
                return View(bookModel);
            }

            return HttpNotFound();
        }

        [ActionName("DeleteBook")]
        [HttpPost]
        public ActionResult FinalDelete(int? id)
        {
            var existingBook = db.Find(p => p.BookId == id);

            if (existingBook != null)
            {
                db.Remove(existingBook);

                return RedirectToAction("GetBooks");
            }

            return HttpNotFound();
        }

        [HttpGet]
        public ActionResult SearchBook(string name)
        {
            Book bookModel = null;

            if (name != null)
            {
                bookModel = db.Find(p => p.Title == name);
                return View(bookModel);
            }
            return HttpNotFound();
        }

    }
}