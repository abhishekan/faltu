﻿using System;
using SimpleCalcDemo;

namespace SimpleCalcClientDemo
{
    class Program : Calculator
    {
        static void Main(string[] args)
        {            
            Calculator calc = new Calculator();
            Console.WriteLine("Addition \"5\" + \"10\" : {0}", calc.Add(5, 10));
            Program p = new Program();
            Console.WriteLine("Product : {0}", p.Multiply(5, 10));
            Console.WriteLine("Remainder : {0}", p.Remainder(5, 2));
        }
    }
}
