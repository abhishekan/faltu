﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimpleCalc
{
    class Program
    {
        static int num1, num2;
       
        public static void ExceptValue()
        {            
            Console.WriteLine("Enter a number");
            if (!int.TryParse(Console.ReadLine(), out num1))
            {
                Console.WriteLine("Invalid entry, expecting any numeric value. Please try again.");
            
            }


            Console.WriteLine("Enter another number");
            if (!int.TryParse(Console.ReadLine(), out num2))
            {
                Console.WriteLine("Invalid entry, expecting any numeric value. Please try again.");
                
            }      
        }

        static void Main(string[] args)
        {
            int operation;
            char choice = 'y';
            char quit = 'n';
            
            do
            {
                Console.WriteLine("Main Menu");
                Console.WriteLine("=====================");
                Console.WriteLine("1.Add");
                Console.WriteLine("2.Subtract");
                Console.WriteLine("3.Divide");
                Console.WriteLine("4.Multiply");
                Console.WriteLine("5.Exit");
                Console.WriteLine("=====================");
                
                Console.WriteLine("Select an operation(1/2/3/4/5)");
                if (!int.TryParse(Console.ReadLine(), out operation))
                {
                    Console.WriteLine("Invalid entry, expecting input between 1 to 5. Please try again.");
                    continue;
                }
                else if (operation == 5)
                {
                    Console.WriteLine("Do you really want to quit?(y/n)");
                    if (!char.TryParse(Console.ReadLine(), out quit))
                    {
                        Console.WriteLine("Invalid entry, expecting a character y or n. Please try again.");
                        continue;
                    }
                    else
                    {
                        if ((quit == 'y') || (quit == 'Y'))
                            break;
                        else
                            continue;
                    }
                }

                
                
                    switch (operation)
                    {
                        case 1:
                            ExceptValue();
                            if ((num1 > 0) && (num2 > 0))
                            {
                            Console.WriteLine("Sum of {0} and {1} is {2}", num1, num2, num1 + num2);
                            }
                            break;
                        case 2:
                            ExceptValue();
                            if ((num1 > 0) && (num2 > 0))
                            {
                                Console.WriteLine("Difference of {0} and {1} is {2}", num1, num2, num1 - num2);
                            }                            
                            break;
                        case 3:
                            ExceptValue();
                            if ((num1 > 0) && (num2 > 0))
                            {
                                Console.WriteLine("Division of {0} and {1} is {2}", num1, num2, num1 / num2);
                            }                              
                            break;
                        case 4:
                            ExceptValue();
                            if ((num1 > 0) && (num2 > 0))
                            {
                                Console.WriteLine("Product of {0} and {1} is {2}", num1, num2, num1 * num2);
                            } 
                            break;
                        default: Console.WriteLine("Invalid entry, please enter any number between 1 to 4");
                            continue;
                    }                
                

                Console.WriteLine("Do you want to continue?(y/n)");
                if(!char.TryParse(Console.ReadLine(), out choice))
                {
                    Console.WriteLine("Invalid entry, expecting a character y or n. Please try again.");
                    continue;
                }
            } while (choice == 'y' || choice == 'Y');
        }
    }
}
