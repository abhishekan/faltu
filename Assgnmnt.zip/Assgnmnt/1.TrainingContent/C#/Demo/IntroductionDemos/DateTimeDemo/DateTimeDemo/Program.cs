﻿using System;


namespace DateTimeDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Current Date and Time {0}", DateTime.Now);
            Console.WriteLine("Current Date {0}", DateTime.Now.ToShortDateString());
            Console.WriteLine("Current Date {0}", DateTime.Now.ToLongDateString());

            Console.WriteLine("Current Time {0}", DateTime.Now.ToShortTimeString());
            Console.WriteLine("Current Time {0}", DateTime.Now.ToLongTimeString());

            //ask date from user
            
            int year, month, day;
            bool outPut;
            Console.WriteLine("Enter Birth Day");
            int.TryParse(Console.ReadLine(), out day);

            if (day != 0)
            {
                Console.WriteLine("Your birthday is {0}", day);
            }
            else
                Console.WriteLine("You have entered invalid data, please try again");

            Console.WriteLine("Enter Month");
            int.TryParse(Console.ReadLine(), out month);

            Console.WriteLine("Enter Year");
            int.TryParse(Console.ReadLine(), out year);

            //create date time object
            DateTime dob = new DateTime(year, month, day);
            Console.WriteLine("Birth Year {0}", dob.Year);
            Console.WriteLine("Birth Month {0}", dob.Month);
            Console.WriteLine("Birth Day {0}", dob.Day);

            TimeSpan duration = new TimeSpan();
            duration = DateTime.Now.Subtract(dob);

            Console.WriteLine("Total Days : {0}", duration.Days);
             
        }
    }
}
