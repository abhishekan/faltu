﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPDemo
{
    abstract class Shape
    {
        int length, breadth;

        public Shape()
        {
            //Console.WriteLine("Shape.Default_Constructor is called");
        }

        public Shape(int l, int b)
        {
            this.length = l;
            this.breadth = b;
            //Console.WriteLine("Shape.Constructor is called");
        }

        public  void CalculateArea()
        {
            Console.WriteLine("Shape.CalculateArea called");
        }

        //public abstract void CalculateArea();
       
    }
}
