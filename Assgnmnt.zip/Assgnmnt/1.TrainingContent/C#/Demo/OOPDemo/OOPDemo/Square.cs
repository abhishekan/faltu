﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPDemo
{
    class Square : Shape
    {
        public Square()
        {
            
        }

        public Square(int l, int b)
            : base(l, b)
        {
            //Console.WriteLine("Square.Constructor is called");
        }

        public  void CalculateArea()
        {
            Console.WriteLine("Square.CalculateArea called");
        }
    }
}
