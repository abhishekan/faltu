﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PropertiesDemo
{
    internal class Employee
    {
        private int empid;

        public Employee()
        {
            this.empid = 1;
        }

        public Employee(int empid)
        {
            this.empid = empid;
        }

        public int EmployeeId
        {
            get { return empid; }
            //set
            //{
            //    if (value > 10)
            //    {
            //        empid = value;
            //    }
            //}
        }

        public string Name { get; set; }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Employee emp = new Employee();
            //emp.EmployeeId = 11;
            //Console.WriteLine("Employee Id : {0}", emp.EmployeeId);

            emp.Name = "Sachin";
            Console.WriteLine("Employee Name : {0}", emp.Name);
        }
    }
}
