

-- a.) Get All the books written by specific author
SELECT * FROM BOOK WHERE BookId IN(SELECT Bid FROM BOOK_AUTHOR WHERE Aid = 2)



-- b.) Get all the books written by specific author and published by specific publisher belonging to “Technical” book Category
select * from BOOK WHERE bookid 
IN (select BookId from BOOK_AUTHOR where Aid=2) 
AND B_Pid=(select PublisherId from PUBLISHER where PublisherName='TechMax')
AND B_Cid=(select categoryid from category where Categoryname ='Technical')



-- c. Get total books published by each publisher.
SELECT B_Pid, COUNT(BookId) FROM BOOK  WHERE B_Pid IN (SELECT DISTINCT(B_Pid) FROM BOOK) GROUP BY B_Pid 



-- d. Get all the books for which the orders are placed.
SELECT * FROM BOOK B, [ORDER] O WHERE B.BookId = O.O_Bid