﻿using BookStoreApp.Repository.EntityDataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookStoreApp.Repository.Abstract
{
    interface iBookRepository
    {
        void i_AddBook(BOOK book);
        IEnumerable<BOOK> i_displayBook();
        BOOK i_findBookById(int id);
        void i_updateBookById(BOOK book);
        void i_RemoveById(int id);
        IEnumerable<BOOK> i_searchBookByTitle(string name);

        //IEnumerable<BOOK> i_All_BooksBy_Specific_Author(string authorName);
        //IEnumerable<BOOK> i_All_booksBy_specificAuthor_and_Publisher_BelongsTo_TechnicalCategory(string authorName, string publisherName, string categoryName);
        //BOOK i_Get_Books_by_eachPublisher();
    }
}
