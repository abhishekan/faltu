﻿
using System;
using System.ComponentModel.DataAnnotations;
namespace BookStoreAppMVC.Models
{
    public class BookView
    {
        [Required]
        public int BookId { get; set; }

        [Required]
        public string Title { get; set; }

        [Required]
        public string Description { get; set; }

        public Nullable<int> Price { get; set; }

        [Required]
        public string ISBN { get; set; }

        [Required]
        public string PublicationDate { get; set; }

        [Required]
        public Nullable<int> B_Cid { get; set; }

        [Required]
        public Nullable<int> B_Pid { get; set; }
    }
}