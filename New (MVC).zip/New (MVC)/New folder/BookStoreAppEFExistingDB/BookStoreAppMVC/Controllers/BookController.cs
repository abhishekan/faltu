﻿using BookStoreApp.Repository;
using BookStoreApp.Repository.EntityDataModel;
using BookStoreAppMVC.Models;
using System;
using System.Collections.Generic;
using System.Web.Mvc;

namespace BookStoreAppMVC.Controllers
{
    [Authorize]
    public class BookController : Controller
    {
        BookRepository repo = new BookRepository();

        [HttpGet]
        public ActionResult GetBooks()
        {
            IEnumerable<BOOK> bookList = repo.i_displayBook();
            List<BookView> List = new List<BookView>();

            foreach (var i in bookList)
            {
                BookView bookViewModel = new BookView();

                bookViewModel.BookId = i.BookId;
                bookViewModel.Title = i.Title;
                bookViewModel.Description = i.Description;
                bookViewModel.Price = i.Price;
                bookViewModel.ISBN = i.ISBN;
                bookViewModel.PublicationDate = i.PublicationDate;
                bookViewModel.B_Cid = i.B_Cid;
                bookViewModel.B_Pid = i.B_Pid;

                List.Add(bookViewModel);
            }
            return View(List);
        }


        [HttpGet]
        public ActionResult GetBookById(int id)
        {
            BOOK book = repo.i_findBookById(id);
            List<BOOK> books = new List<BOOK>();
            books.Add(book);
            IEnumerable<BOOK> bookList = (IEnumerable<BOOK>)books;
            List<BookView> List = new List<BookView>();

            foreach (var i in bookList)
            {
                BookView bookViewModel = new BookView();

                bookViewModel.BookId = i.BookId;
                bookViewModel.Title = i.Title;
                bookViewModel.Description = i.Description;
                bookViewModel.Price = i.Price;
                bookViewModel.ISBN = i.ISBN;
                bookViewModel.PublicationDate = i.PublicationDate;
                bookViewModel.B_Cid = i.B_Cid;
                bookViewModel.B_Pid = i.B_Pid;

                List.Add(bookViewModel);
            }
            return View(List);
        }


        [HttpGet]
        public ViewResult AddBook()
        {
            return View();
        }

        [HttpPost]
        public ActionResult AddBook(BookView bookViewModel)
        {
            BOOK book = new BOOK();

            book.BookId = bookViewModel.BookId;
            book.Title = bookViewModel.Title;
            book.Description = bookViewModel.Description;
            book.Price = bookViewModel.Price;
            book.ISBN = bookViewModel.ISBN;
            book.PublicationDate = bookViewModel.PublicationDate;
            book.B_Cid = bookViewModel.B_Cid;
            book.B_Pid = bookViewModel.B_Pid;

            repo.i_AddBook(book);

            return RedirectToAction("GetBooks");
        }


        [HttpGet]
        public ActionResult UpdateBook(int id)
        {
            BOOK book = repo.i_findBookById(id);
            BookView bookViewModel = new BookView();

            bookViewModel.BookId = book.BookId;
            bookViewModel.Title = book.Title;
            bookViewModel.Description = book.Description;
            bookViewModel.Price = book.Price;
            bookViewModel.ISBN = book.ISBN;
            bookViewModel.PublicationDate = book.PublicationDate;
            bookViewModel.B_Cid = (int)book.B_Cid;
            bookViewModel.B_Pid = (int)book.B_Pid;

            return View(bookViewModel);
        }

        [HttpPost]
        public ActionResult UpdateBook(BookView bookViewModel)
        {
            BOOK book = new BOOK();

            book.BookId = bookViewModel.BookId;
            book.Title = bookViewModel.Title;
            book.Description = bookViewModel.Description;
            book.Price = bookViewModel.Price;
            book.ISBN = bookViewModel.ISBN;
            book.PublicationDate = bookViewModel.PublicationDate;
            book.B_Cid = bookViewModel.B_Cid;
            book.B_Pid = bookViewModel.B_Pid;

            repo.i_updateBookById(book);

            return RedirectToAction("GetBooks");
        }


        [Authorize(Roles = "admin")]
        [HttpGet]
        public ActionResult DeleteBook(int id)
        {
            BOOK book = repo.i_findBookById(id);
            List<BOOK> books = new List<BOOK>();
            books.Add(book);
            IEnumerable<BOOK> bookList = (IEnumerable<BOOK>)books;
            List<BookView> List = new List<BookView>();

            foreach (var i in bookList)
            {
                BookView bookViewModel = new BookView();

                bookViewModel.BookId = i.BookId;
                bookViewModel.Title = i.Title;
                bookViewModel.Description = i.Description;
                bookViewModel.Price = i.Price;
                bookViewModel.ISBN = i.ISBN;
                bookViewModel.PublicationDate = i.PublicationDate;
                bookViewModel.B_Cid = i.B_Cid;
                bookViewModel.B_Pid = i.B_Pid;

                List.Add(bookViewModel);
            }
            return View(List);
        }

        [ActionName("DeleteBook")]
        [HttpPost]
        public ActionResult FinalDelete(int id)
        {
            repo.i_RemoveById(id);
            return RedirectToAction("GetBooks");
        }


        [Authorize(Users = "Anand")]
        [HttpGet]
        public ActionResult SearchBook(string name)
        {
            if (name != null)
            {
                IEnumerable<BOOK> bookList2 = null;
                bookList2 = repo.i_searchBookByTitle(name);
                
                List<BookView> List2 = new List<BookView>();              

                foreach (var i in bookList2)
                {
                    BookView bookViewModel2 = new BookView();
               
                    bookViewModel2.BookId = i.BookId;
                    bookViewModel2.Title = i.Title;
                    bookViewModel2.Description = i.Description;
                    bookViewModel2.Price = i.Price;
                    bookViewModel2.ISBN = i.ISBN;
                    bookViewModel2.PublicationDate = i.PublicationDate;
                    bookViewModel2.B_Cid = i.B_Cid;
                    bookViewModel2.B_Pid = i.B_Pid;

                    List2.Add(bookViewModel2);
                }
                return View(List2);
            }
            else
            {
                return HttpNotFound();
            }
        }
    }
}