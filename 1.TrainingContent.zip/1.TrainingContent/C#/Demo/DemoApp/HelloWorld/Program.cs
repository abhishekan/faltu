﻿
using System;
namespace HelloWorld
{
    //The class that contains Main method
    class Program
    {
        /// <summary>
        /// The entry point of the program
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            //Console.WriteLine("Hello C#");
            string name;
            int id;
            int salary;

            Console.WriteLine("Enter name");
            name = Console.ReadLine();

            Console.WriteLine("Enter Id");
            id = int.Parse(Console.ReadLine());

            Console.WriteLine("Will you tell me your salary?");
            if (!int.TryParse(Console.ReadLine(), out salary))
            {
                Console.WriteLine("Invalid input, please enter only numeric value");
            }

            Console.WriteLine("You entered name : {0}, id : {1} and Salary : {2}", name, id, salary);
        }
    }
}
