﻿using MyProductStore.Core;
using System.Collections.Generic;

namespace MyProductStore.Repository.Abstract
{
    interface ICustomerRepository
    {
        IEnumerable<Customer> GetCustomers();
        Customer GetCustomerById(int id);
        void SaveCustomer(Customer customer);
        Customer DeleteCustomer(int id);
    }
}
