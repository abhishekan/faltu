﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionHandlingDemo
{
    class MyException : ApplicationException
    {
        public MyException(string message) : base(message)
        {

        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            try
            {

            }
            finally
            {

            }

            //int a = 5 / 0;
            try
            {
                //throw new DivideByZeroException();
                //throw new IndexOutOfRangeException();
                //throw new System.IO.FileNotFoundException();
                //throw new InvalidCastException();
                //throw new NullReferenceException();
                throw new MyException("Throwing custom exception");
            }
            catch(MyException ex)
            {
                Console.WriteLine("Some exception occurred : {0}", ex.Message);
            }
            catch(DivideByZeroException ex)
            {
                //you can write any alternate solution here
                //or display error messages
                Console.WriteLine("Some exception occurred : {0}", ex.Message);
            }
            catch(IndexOutOfRangeException ex)
            {
                Console.WriteLine("Some exception occurred : {0}", ex.Message);
            }
            catch(System.IO.FileNotFoundException ex)
            {
                Console.WriteLine("Some exception occurred : {0}", ex.Message);
            }
            catch(NullReferenceException ex)
            {
                Console.WriteLine("Some exception occurred : {0}", ex.Message);
            }
            catch(Exception ex)
            {
                Console.WriteLine("Base class handling the exception : {0}", ex.Message);
            }
            finally
            {
                //clean up code
                Console.WriteLine("finally block executed");
            }
            Console.WriteLine("Out of try catch");
        }
    }
}
