﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleInputOutputDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            string name;
            int empId;
            Console.WriteLine("Enter Name");
            name = Console.ReadLine();
            Console.WriteLine("Enter Employee Id");
            empId = int.Parse(Console.ReadLine());
            Console.WriteLine("Name : {0}, Employee Id : {1}", name, empId);
        }
    }
}
