﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BookStoreApp.Core;

namespace BookStoreApp.Repository
{
    public class BookRepository
    {
        int bookId;
        string category;
        string title;
        string author;
        string publisher;
        string description;
        float price;
        string isbn;
        string publicationDate;

        List<Book> bookList = new List<Book>();


        public void AddBook()
        {

            Console.WriteLine();
            Console.Write("Enter the book id: ");
            if (!int.TryParse(Console.ReadLine(), out bookId))
            {
                Console.WriteLine("Invalid entry, expecting any numeric value. Please try again. . .");
            }

            Console.Write("Enter the book Category: ");
            string category = Console.ReadLine();

            Console.Write("Enter the book Name: ");
            string title = Console.ReadLine();

            Console.Write("Enter the book Author: ");
            string author = Console.ReadLine();

            Console.Write("Enter the book Publication: ");
            string publisher = Console.ReadLine();

            Console.Write("Enter the book Description: ");
            string description = Console.ReadLine();

            Console.Write("Enter the book Price: ");
            if (!float.TryParse(Console.ReadLine(), out price))
            {
                Console.WriteLine("Invalid entry, expecting any numeric value. Please try again.");
            }

            Console.Write("Enter the book ISBN: ");
            string isbn = Console.ReadLine();

            Console.Write("Enter the publication date: ");
            string publicationDate = Console.ReadLine();

            Book b1 = new Book(bookId, category, title, author, publisher, description, price, isbn, publicationDate);
            bookList.Add(b1);

            Console.WriteLine();
            Console.WriteLine("Book is Added. . . ");

        }


        public void displayBook()
        {
            foreach (Book b in bookList)
            {
                Console.WriteLine();
                Console.WriteLine(". Book id:{0}\n, Category :{1}\n, Book Name:{2}\n, Author:{3}\n, Publication:{4}\n, Description:{5}\n, Price:{6}\n, ISBN:{7}\n, PDate:{8}\n", b.BookId, b.Category, b.Title, b.Author, b.Publisher, b.Description, b.Price, b.ISBN, b.PublicationDate);
            }
        }


        public void findBookById()
        {
            Console.WriteLine();
            Console.Write("Enter the book id to be searched: ");
            int id = int.Parse(Console.ReadLine());
            Book b2 = bookList.Find(findBook => findBook.BookId == id);
            Console.WriteLine(". Book id:{0}\n, Category :{1}\n, Book Name:{2}\n, Publication:{3}\n, Description:{4}\n, Price:{5}\n, ISBN:{6}\n, PDate:{7}\n", b2.BookId, b2.Category, b2.Title, b2.Publisher, b2.Description, b2.Price, b2.ISBN, b2.PublicationDate);
        }

        public void updateBookById()
        {
            try
            {
                Console.WriteLine();
                Console.Write("Enter the book id to be updated: ");
                int id = int.Parse(Console.ReadLine());
                Book b2 = bookList.Find(findBook => findBook.BookId == id);
                Console.WriteLine("Press 1 to Update Publisher\nPress 2 to Update PublicationDate\nPress 3 to Update Price\n");

                int choice = int.Parse(Console.ReadLine());

                switch (choice)
                {
                    case 1: Console.Write("Enter the publisher name: ");
                            b2.Publisher = Console.ReadLine();
                            bookList.RemoveAt(id - 1);
                            bookList.Add(b2);
                            break;

                    case 2:
                            Console.Write("Enter the PublicationDate: ");
                            publicationDate = Console.ReadLine();
                            bookList.RemoveAt(id - 1);
                            bookList.Add(b2);
                            break;

                    case 3:
                            Console.Write("Enter the Price: ");
                            b2.Price = float.Parse(Console.ReadLine());
                            bookList.RemoveAt(id - 1);
                            bookList.Add(b2);
                            break;

                    default: Console.WriteLine("Invalid option. . .");
                            break;

                }
                Console.WriteLine("Book updated. . . ");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Invalid id. . .", ex.Message);
            }
        }



        public void RemoveById()
        {
            Console.WriteLine();
            Console.Write("Enter the book id to be Deleted:");
            int id = int.Parse(Console.ReadLine());
            bookList.RemoveAt(id - 1);
            Console.WriteLine("Book is removed. . . ");

        }
    }
}


