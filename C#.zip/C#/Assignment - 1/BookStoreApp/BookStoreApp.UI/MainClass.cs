﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BookStoreApp.Repository;

namespace BookStoreApp.UI
{
    class MainClass
    {
        static void Main(string[] args)
        {
            BookRepository res = new BookRepository();
            int i;
            do
            {
                Console.WriteLine();
                Console.WriteLine("-------------------------------MAIN MENU------------------------------- ");
                Console.WriteLine(" 1) Adding new books\n 2) Displaying all books\n 3) Displaying a book by BookId\n 4) Updating a book by BookId\n 5) Deleting a book by BookId\n 6) Exit\n\n Enter Your Choice(any number from 1 to 6): ");
                
                if(!int.TryParse(Console.ReadLine(), out i))
                {
                    Console.WriteLine("Invalid Option.......");
                }

                switch(i)
                {
                    case 1: res.AddBook();
                            break;


                    case 2: res.displayBook();
                            break;


                    case 3: try
                            {
                                res.findBookById();
                            }
                            catch(Exception ex)
                            {
                                Console.WriteLine("Invalid id. . .",  ex.Message);
                            }
                        break;


                    case 4: res.updateBookById();                
                            break;


                    case 5: try
                            {
                                res.RemoveById();
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine("Invalid id. . .", ex.Message);
                            }
                            break;


                    case 6: Console.WriteLine("Exit. . .");
                            break;


                    default: Console.WriteLine("Invalid option. . . ");
                             Console.WriteLine();
                             break;
                }
            } while(true);
          
            Console.ReadLine();
        }
    }
}
    

