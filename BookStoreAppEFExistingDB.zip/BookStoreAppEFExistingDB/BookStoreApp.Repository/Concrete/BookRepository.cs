﻿using BookStoreApp.Repository.EntityDataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookStoreApp.Repository.Concrete
{
    public class BookRepository
    {
        BookStoreDBEntities context = new BookStoreDBEntities();
        public IEnumerable<BOOK> GetAllBooks()
        {
            return context.BOOKs.ToList();
        }

        public BOOK GetBook(int BookId)
        {
            return context.BOOKs.Find(BookId);
        }

        public void AddBook(BOOK book)
        {
            
            context.BOOKs.Add(book);
            context.SaveChanges();
            Console.WriteLine("Book Added Successfully");
        }

        public void deleteBookById(int BookId)
        {
            BOOK book = context.BOOKs.Find(BookId);
            context.BOOKs.Remove(book);
            context.SaveChanges();
            Console.WriteLine("Book Removed Successfully");
        }

        public void UpdateBookById(BOOK book)
        {
            context.SaveChanges();
        }
    }
}
