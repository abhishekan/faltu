﻿using System;

namespace MyBookStore.ConsoleUI
{
    class Program
    {

        static void Main(string[] args)
        {
            BookStoreManager bm = new BookStoreManager();
        BEGIN: for (; ; )
            {
                Console.WriteLine("<=========================================MENU===============================>");
                Console.WriteLine
                    ("1. Adding new books" + "\n" +
                       "2. Displaying all books" + "\n" +
                       "3. Displaying a book by BookId" + "\n" +
                       "4. Update a book " + "\n" +
                       "5. Delete a book " + "\n" +
                       "6. Get Books Written By Specific Author" + "\n" +
                       "7. Get Books Belongs to Tecnical Category & Written by Specific Author&Publisher" +
                       "8. Get Total Book Published BY Each Company" + "\n" +
                       "9. Exit"
                    );
                int choice;

                if (!int.TryParse(Console.ReadLine(), out choice))
                {
                    Console.WriteLine("Enter Numiriacal Value e.g 1");
                    goto BEGIN;
                }
                switch (choice)
                {
                    case 1: Console.WriteLine("Adding book");
                        bm.addBookToStore();                            //Calling addBookStore Method

                        break;
                    case 2: 
                        bm.bookDisplayStore();                          //Calling method for displaying all Books
                        break;
                    case 3: Console.WriteLine(" Showing Book by Id");
                        bm.showBook();                                  //Calling Show book method
                        break;
                    case 4: Console.WriteLine("Updating by Id");
                        bm.updateBookById();                            //Calling Update Method
                        break;
                    case 5: Console.WriteLine("Deleting by Id");
                        bm.deleteBookById();                            //Calling Delete Method
                        break;
                    case 6: bm.BookWrittenByAuthor();                       //Book Written by specific Author
                        break;
                    //case 7: bm.BookBelongToTechnical();                     //Books Belonging To Technical Category
                    //    break;
                    //case 8: bm.TotalBookByEachCompany();
                    //    break;
                    case 9: Console.WriteLine("Exiting");
                        Environment.Exit(0);                            //Exiting From Menu
                        break;
                    default: Console.WriteLine("Enter Choice Given Above");
                        break;
                }

            }
        }
    }
}
