﻿using BookStoreApp.Repository.Concrete;
using BookStoreApp.Repository.EntityDataModel;
using System;
using System.Collections.Generic;


namespace MyBookStore.ConsoleUI
{
    class BookStoreManager
    {
        BookRepository Repo = new BookRepository();
        int BookId;                                             //Declaring BookID Variable it is Usefull or all fallowing methods
          public void addBookToStore()
           {
               int BookQuantity, Price, PublisherId, CategoryId;
               DateTime Date;

               BOOK bk = new BOOK();


               Console.Write("Please Enter Book title:     ");
               bk.Title = Console.ReadLine();

               Console.Write("Please Enter Book Description:");
               bk.Description = Console.ReadLine();

           PRICE: Console.Write("Please Enter Book price:     ");
               while (!int.TryParse(Console.ReadLine(), out Price))
               {
                   Console.Write("Please Enter Numeric Book Price e.g 500:");
               }
               try
               {
                   if (Price <= 0)
                   {
                       throw new PriceException("Please Provide price Greater than Zero");
                   }
                   else
                   {
                       bk.Price = Price;
                   }
               }
               catch (PriceException ex)
               {
                   Console.Write(ex.message);
                   goto PRICE;
               }

               Console.Write("Please Enter Book ISBN:      ");

               bk.ISBN = Console.ReadLine();


               Console.Write("Please Enter Book Publication Date:");
               while (!DateTime.TryParse(Console.ReadLine(), out Date))
               {
                   Console.Write("Enter Enter Date e.g MM/DD/YYYY:");
               }

               bk.PublicatioinDate = Date;

               Console.Write("Please Enter Book Publisher ID:");
               while (!int.TryParse(Console.ReadLine(), out PublisherId))
               {
                   Console.Write("Please Enter Numeric Publication Id e.g 1:");
               }
               bk.PublisherId = PublisherId;



               Console.Write("Please Enter Category ID:    ");
               while (!int.TryParse(Console.ReadLine(), out CategoryId))
               {
                   Console.Write("Please Enter Numeric Id e.g 1:  ");
               }
               bk.CategoryId = CategoryId;

               Console.Write("Please Enter BookQuantity:    ");
               while (!int.TryParse(Console.ReadLine(), out BookQuantity))
               {
                   Console.Write("Please Enter Numeric Id e.g 1:  ");
               }
               bk.BookQuantity = BookQuantity;

               Repo.AddBook(bk);
               //Console.WriteLine("Book is Added to the Database");

           }

  
        public void bookDisplayStore()
        {
            IEnumerable<BOOK> blst = Repo.GetAllBooks();
            List<BOOK> bookslst = (List<BOOK>)blst;
            DisplayBooks(bookslst);

        }


        public void showBook()
        {

            Console.WriteLine("Please Enter Book ID");
            while (!int.TryParse(Console.ReadLine(), out BookId))
            {
                Console.WriteLine("Please Enter Numeric Value e.g 10");
            }

            BOOK bk = Repo.GetBook(BookId);

            if (bk != null)
            {


                Console.WriteLine("Book Id             :{0}" + "\n" +
                                      "Book Name           :{1}" + "\n" +
                                      "Book Description    :{2}" + "\n" +
                                      "Book Price          :{3}" + "\n" +
                                      "Book ISBN           :{4}" + "\n" +
                                      "Book PublicationDate:{5}" + "\n" +
                                      "Book Publisher ID   :{6}" + "\n" +
                                      "Book Category Id    :{7}" + "\n" +
                                      "Book Quantity       :{8}" + "\n",
                                      bk.BookId, bk.Title, bk.Description, bk.Price, bk.ISBN, bk.PublicatioinDate, bk.PublisherId, bk.CategoryId, bk.BookQuantity

                                      );

            }
            else
            {
                Console.WriteLine("Book not Available THANK YOU for Visiting");
            }

        }

        //Update Book By Id
        public void updateBookById()
        {
            int Price;

            Console.WriteLine("Please Enter Book ID");
            while (!int.TryParse(Console.ReadLine(), out BookId))
            {
                Console.WriteLine("Please Enter Numeric Value e.g 10");
            }



            BOOK bk = Repo.GetBook(BookId);

            if (bk == null)
            {
                Console.WriteLine("Book with Id={0} Not Available in Book Store to update", BookId);
            }
            else
            {

                int ch;
                for (; ; )                                                                               //Updating book...
                {


                    Console.WriteLine(" 1.Update Price \n 2.Update Title \n 3.Update");
                    while (!int.TryParse(Console.ReadLine(), out ch))
                    {
                        Console.WriteLine("Enter Numeric value e.g 1");
                    }
                    switch (ch)
                    {
                        case 1: Console.WriteLine("Please New Price");
                            while (!int.TryParse(Console.ReadLine(), out Price))
                            {
                                Console.WriteLine("Please Enter Numeric Book Price e.g 500");
                            }
                            bk.Price = Price;
                            Console.WriteLine("Price Updated");
                            break;
                        case 2: Console.WriteLine("Enter New Title");
                            bk.Title = Console.ReadLine();
                            Console.WriteLine("Title Updated");
                            break;

                        case 3: Console.WriteLine("You Exit From Update");
                            Repo.UpdateBookById(bk);
                            return;

                        default: Console.WriteLine("Enter Choice between 1,2,3");
                            break;

                    }

                }
            }

        }

        //Delete Book By Id
        public void deleteBookById()
        {
            Console.WriteLine("Please Enter Book ID");
            while (!int.TryParse(Console.ReadLine(), out BookId))
            {
                Console.WriteLine("Please Enter Numeric Value e.g 10");
            }


            Repo.deleteBookById(BookId);

            //int count = Repo.deleteBookById(BookId);
            //if (count == 0)
            //{
            //    Console.WriteLine("Book is not available in store");
            //}
            //else
            //{
            //    Console.WriteLine("Book with id={0} is deleted", BookId);
            //}

        }


        //Book Written By Specific Author
        public void BookWrittenByAuthor()
        {
            Console.WriteLine("Enter Author Name");
            IEnumerable<BOOK> blst = Repo.GetAllBooks(Console.ReadLine());
            List<BOOK> bookslst = (List<BOOK>)blst;
            DisplayBooks(bookslst);

        }

/*
        //Book Belong to Technical Category
        public void BookBelongToTechnical()
        {
            String author, publisher;
            Console.WriteLine("Enter Author Name");
            author = Console.ReadLine();
            Console.WriteLine("Enter Publisher Name");
            publisher = Console.ReadLine();
            IEnumerable<Book> blst = Repo.GetAllBooks(author, publisher);
            List<Book> bookslst = (List<Book>)blst;
            DisplayBooks(bookslst);
        }

*/
        //Function For Displaying Books
        public void DisplayBooks(List<BOOK> list)
        {
            if (!(list.Count == 0))
            {
                foreach(BOOK bk in list)
                {
                    Console.WriteLine("Book Id             : {0}" + "\n" +
                                       "Book Name           : {1}" + "\n" +
                                       "Book Description    : {2}" + "\n" +
                                       "Book Price          : {3}" + "\n" +
                                       "Book ISBN           : {4}" + "\n" +
                                       "Book PublicationDate: {5}" + "\n" +
                                       "Book Publisher ID   : {6}" + "\n" +
                                       "Book Category Id    : {7}" + "\n" +
                                       "Book Quantity       : {8}" + "\n",
                                       bk.BookId, bk.Title, bk.Description, bk.Price, bk.ISBN, bk.PublicatioinDate, bk.PublisherId, bk.CategoryId, bk.BookQuantity

                                       );
                    Console.WriteLine("------------------------------------------------------------------------------");
                }

            }
            else
            {
                Console.WriteLine("Book not Available THANK YOU for Visiting");
            }
        }

/*
        //Function For total book produce by each Company
        public void TotalBookByEachCompany()
        {
            List<Publisher> list = (List<Publisher>)Repo.TotalBookByCompany();
            if (list.Count != 0)
            {
                foreach (Publisher pb in list)
                {
                    Console.WriteLine("PublisherName:       {0}" + "\n" +
                                      "Total Book Published:{1}",
                                      pb.PublisherName, pb.Count
                                     );
                    Console.WriteLine("------------------------------------------------------------------------------");
                }
            }

        }
 */
    }
}
