﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace BinaryFileDemoApplication
{
    class Program
    {
        static void Main(string[] args)
        {

            using (FileStream fs = new FileStream(@"D:\Binaryfile.txt", FileMode.OpenOrCreate))
            {
                //writing the data into file in the binary format

                using (BinaryWriter writer = new BinaryWriter(fs))
                {
                    writer.Write("Srusti Bisen");
                    writer.Write("5.90f");
                    writer.Write(10);
                    Console.WriteLine("writing is done in the file in the binary format....");
                    Console.ReadLine();
                }


                //reading the data from the file into the console....
                //string name;
                //float num1;
                //int num2;


                //using (BinaryReader reader = new BinaryReader(fs))
                //{

                //    name = reader.ReadString();
                //    num1 = reader.ReadSingle();
                //    num2 = reader.ReadInt32();

                //    Console.WriteLine("Name is :" + name);
                //    Console.WriteLine("1st Number Is:" + num1);
                //    Console.WriteLine("2nd Number Is:" + num2);


                //    Console.WriteLine("Reading  of file....");

                //    Console.ReadLine();



                //}




            }


        }

    }

}
