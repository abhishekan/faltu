﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace EventDelegateFileConsoleApp
{
    //delegate..
     public delegate void WritingDelegate();

    class Program
    {

        //method for writing into the file...

        public static void Writingintofile()
        {
            using (FileStream file = new FileStream(@"D:\FileDelegate.txt", FileMode.OpenOrCreate))
            {
                using (StreamWriter writer = new StreamWriter(file))
                {
                    writer.Write("Writing Into File Through Delegate...");
                    Console.WriteLine("Writing in file is done..");
                    Console.ReadLine();
                }
            }
                

        
        }

        //method for writing into Console....

        public static void WritingintoConsole()
        {
            Console.WriteLine("Writing into Console Through Delegate. . . . . . . ");
            Console.ReadLine();
        }

        static void Main(string[] args)
        {

            WritingDelegate wd1 = new WritingDelegate(Writingintofile);

            wd1();


            WritingDelegate wd2 = new WritingDelegate(WritingintoConsole);

            wd2();



            


        }
    }
}
